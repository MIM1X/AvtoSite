<?php
$connect = mysqli_connect(hostname:'127.0.0.1',username:'root', password:'', database:'cardetailshop');
if($connect){
     echo 'Всё оки-доки!';
} 